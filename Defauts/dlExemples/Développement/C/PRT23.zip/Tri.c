#include <stdio.h>
#include <stdlib.h>


	int triTab(int tableau[] ,int nbCase,int plusPetit,int i,int tour);

	int main()
	{
		int tableau[5] = {2,7,3,1,6},i=0;

		printf("%ld",triTab(tableau, 5,tableau[0],0,0));

		for(i=0;i<5;i++)
		printf("%ld\n", tableau[i]);
	}

	int triTab(int tableau[],int nbCase,int plusPetit,int i,int tour)
	{
		if( (tour + i) == nbCase)
		{
			tableau[tour] = plusPetit;
			triTab(tableau,nbCase,tableau[tour++],0,tour++);
		}

		if(tour == nbCase)
			return 10;

			if(tableau[tour + i] < plusPetit)
			{
				plusPetit = tableau[i];
				triTab(tableau,nbCase,plusPetit,i++,tour);
			}
		else
		{
			triTab(tableau,nbCase,plusPetit,i++,tour);
		}
	}