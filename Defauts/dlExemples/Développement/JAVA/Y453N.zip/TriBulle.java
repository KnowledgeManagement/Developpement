public class Mtab2
{
		// remplir
		// disp
		//méthode tri à bulles
		public static void tribulles(int t[])
		{
				for (int i=0 ;i<=(t.length-2);i++)
						for (int j=(t.length-1);i < j;j--)
								if (t[j] < t[j-1])
								{
										int x=t[j-1];
										t[j-1]=t[j];
										t[j]=x;
								}
		} // fin tri
		// recherche
		public static void main(String  args[])
		{
				TextWindow.print("Entrer la taille du tableau");
				int taille=TextWindow.readInt();
				TextWindow.printLine("\n\n taille="+taille+"\n");
				int []t ;
				t=new int[taille] ;
				remplir(t) ;
				TextWindow.printLine("Avant le tri");
				disp(t) ;
				tribulles(t) ;
				TextWindow.printLine("Après le tri");
				disp(t) ;
				TextWindow.print("Entrer le nb x à chercher");
				int x=TextWindow.readInt() ;
				if(recherche(t,x)) TextWindow.pintLine(x+"est ds t");
				else TextWindow.printLine(x+"n’est pas ds t");
		} // fin main
} // fin class