#include <iostream> 
using namespace std;
const int N = 2;
const int M = 3;
 
int main()
{
    int i, j;
    int t[N][M];
 
    for(i=0; i<N; i++) 
      for(j=0; j<M; j++) 
      {
        cout<<"Tapez t["<< i <<"]["<< j <<"] :";
        cin >> t[i][j];
      }
 
    cout<<"Voici le tableau :"<<endl; 
    for(i=0; i<N; i++) 
    { 
      for(j=0; j<M; j++) cout<< t[i][j] <<" "; 
      cout<<endl; 
    } 
    return 0; 
}